const express = require("express");

const app = express();
app.use("/uploads", express.static("uploads"));
app.use(express.json());
const cors = require("cors");
app.use(cors());

// const PG = require("./models/Pg");

// GET
// app.get("/api/pg", (req, res) => {
//   res.json(pgs);
// });

// POST
app.post("/api/pg", async (req, res) => {
  try {
    const newPG = new PG(req.body);   // ✅ MongoDB model
    await newPG.save();               // ✅ save in DB

    res.json(newPG);                  // ✅ response
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE
app.delete("/api/pg/:id", (req, res) => {
  pgs = pgs.filter(pg => pg._id !== req.params.id);
  res.json({ message: "Deleted" });
});

app.put("/api/pg/:id", async (req, res) => {
  const updated = await PG.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

// START
app.listen(5000, () => {
  console.log("🚀 Server running on http://localhost:5000");
});

app.get("/", (req, res) => {
  res.send("🚀 Backend is running successfully");
});


const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://dhirendrajha:251405@cluster.lki1eh2.mongodb.net/pgDatabase")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));


const PG = require("./models/Pg");

app.get("/api/pg", async (req, res) => {
  try {
    const data = await PG.find();  // ✅ MongoDB se data
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/pg", async (req, res) => {
  try {
    const newPG = new PG(req.body);
    await newPG.save();
    res.json(newPG);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});





require("dotenv").config();

app.post("/api/ai", async (req, res) => {
  const { message } = req.body;

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: message }]
      })
    });

    const data = await response.json();
    res.json({ reply: data.choices[0].message.content });

  } catch (err) {
    res.status(500).json({ reply: "AI error 😢" });
  }
});

app.listen(5000, () => console.log("Server running on 5000"));