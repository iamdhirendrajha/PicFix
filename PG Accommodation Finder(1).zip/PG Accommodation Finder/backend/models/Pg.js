const mongoose = require("mongoose");

const pgSchema = new mongoose.Schema({
  title: String,
  location: String,
  price: Number,
  description: String,
  image: String,
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

module.exports = mongoose.model("PG", pgSchema);

module.exports = mongoose.model("PG", pgSchema, "pgs");
