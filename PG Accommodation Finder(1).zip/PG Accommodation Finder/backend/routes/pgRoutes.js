const express = require("express");
const router = express.Router();

const {
  getAllPGs,
  addPG,
  deletePG,
  updatePG
} = require("../controllers/pgControllers");

router.get("/", getAllPGs);
router.post("/", addPG);
router.delete("/:id", deletePG);
router.put("/:id", updatePG);

module.exports = router;