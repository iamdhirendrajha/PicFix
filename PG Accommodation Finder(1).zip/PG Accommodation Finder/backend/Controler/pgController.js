const Pg = require("../models/Pg");

exports.getAllPGs = async (req, res) => {
  const data = await Pg.find();
  res.json(data);
};

exports.addPG = async (req, res) => {
  const pg = new Pg(req.body);
  await pg.save();
  res.json(pg);
};

exports.deletePG = async (req, res) => {
  await Pg.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted" });
};

exports.updatePG = async (req, res) => {
  const updated = await Pg.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
};


const Pg = require("../models/Pg");

// GET all PGs
exports.getAllPGs = async (req, res) => {
  try {
    const pgs = await Pg.find();
    res.json(pgs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ADD PG
exports.addPG = async (req, res) => {
  try {
    const pg = new Pg(req.body);
    await pg.save();
    res.json(pg);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE PG
exports.deletePG = async (req, res) => {
  try {
    await Pg.findByIdAndDelete(req.params.id);
    res.json({ message: "Deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};