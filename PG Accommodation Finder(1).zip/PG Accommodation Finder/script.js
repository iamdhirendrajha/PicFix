console.log("JS LOADED");

const API = "http://localhost:5000/api/pg";
let allPGs = [];

// ================= LOAD PGs =================
async function loadPGs() {
  const container = document.getElementById("pgContainer");
  if (!container) return;

  try {
    const res = await fetch(API);
    const data = await res.json();

    allPGs = data;
    displayPGs(data);
  } catch (err) {
    showToast("Error loading data ❌");
  }
}

// ================= IMAGE FIX =================
function getImage(img) {
  if (!img) return "https://picsum.photos/400";

  if (img.startsWith("/")) {
    return "http://localhost:5000" + img;
  }

  return img;
}

// ================= DISPLAY =================
function displayPGs(data) {
  const container = document.getElementById("pgContainer");
  if (!container) return;

  container.innerHTML = "";

  if (data.length === 0) {
    container.innerHTML = "<p style='text-align:center'>No PGs found 😢</p>";
    return;
  }

  data.forEach(pg => {
    const card = document.createElement("div");
    card.className = "card"; // UI same

    card.innerHTML = `
  <img src="${pg.image || 'https://via.placeholder.com/400'}" style="width:100%; border-radius:10px;">
  
  <h3 style="margin-top:10px;">${pg.title}</h3>
  <p>📍 ${pg.location}</p>
  <p><strong>₹${pg.price}</strong></p>

  <button class="btn" style="margin-top:10px;"
    onclick="event.stopPropagation(); toggleFavorite('${pg._id}')">
    ${getFavorites().includes(pg._id) ? "❌ Remove" : "❤️ Favorite"}
  </button>
`;

    // ✅ CLICK → DETAILS PAGE
    card.addEventListener("click", () => {
      localStorage.setItem("selectedPG", JSON.stringify(pg));
      window.location.href = "details.html";
    });

    container.appendChild(card);
  });
}

// ================= FAVORITES =================
function getFavorites() {
  return JSON.parse(localStorage.getItem("favorites")) || [];
}

function toggleFavorite(id) {
  let fav = getFavorites();

  if (fav.includes(id)) {
    fav = fav.filter(x => x !== id);
    showToast("Removed from Favorites ❌");
  } else {
    fav.push(id);
    showToast("Added to Favorites ❤️");
  }

  localStorage.setItem("favorites", JSON.stringify(fav));
}

// ================= LOAD FAVORITES =================
async function loadFavorites() {
  const fav = getFavorites();

  try {
    const res = await fetch(API);
    const data = await res.json();

    const favData = data.filter(pg => fav.includes(pg._id));
    displayPGs(favData);
  } catch {
    showToast("Error loading favorites ❌");
  }
 if (fav.length === 0) {
  const container = document.getElementById("pgContainer");
  container.innerHTML = `
    <div style="text-align:center; margin-top:40px;">
      <h2>No Favorites Yet 😢</h2>
      <p>Go to listings and add some ❤️</p>
      <a href="listings.html">
        <button class="btn">Explore PGs</button>
      </a>
    </div>
  `;
  return;
}
}


// ================= FILTER =================
function setupFilters() {
  const searchInput = document.getElementById("searchInput");
  const priceFilter = document.getElementById("priceFilter");

  if (!searchInput || !priceFilter) return;

  searchInput.addEventListener("input", applyFilters);
  priceFilter.addEventListener("change", applyFilters);
}

function applyFilters() {
  let filtered = allPGs;

  const search = document.getElementById("searchInput").value.toLowerCase();
  const price = document.getElementById("priceFilter").value;

  if (search) {
    filtered = filtered.filter(pg =>
      pg.title.toLowerCase().includes(search) ||
      pg.location.toLowerCase().includes(search)
    );
  }

  if (price) {
    filtered = filtered.filter(pg => pg.price <= price);
  }

  displayPGs(filtered);
}

// ================= TOAST =================
function showToast(msg) {
  const div = document.createElement("div");
  div.className = "toast";
  div.innerText = msg;

  document.body.appendChild(div);

  setTimeout(() => {
    div.remove();
  }, 2000);
}

// ================= INIT =================
document.addEventListener("DOMContentLoaded", () => {
  setupFilters();

  if (window.location.pathname.includes("favorites")) {
    loadFavorites();
  } else {
    loadPGs();
  }
});



// const user = localStorage.getItem("user");

// if (user) {
//   document.getElementById("userName").innerText = "👤 " + user;
// }

// function logout() {
//   localStorage.removeItem("user");
//   alert("Logged out 👋");
//   window.location.href = "login.html";
// }


/// ================= NAVBAR LOAD =================
// function loadNavbar() {
//   const nav = document.getElementById("navbar");

//   if (!nav) return;

//   fetch("navbar.html")
//     .then(res => res.text())
//     .then(data => {
//       nav.innerHTML = data;

//       // 👇 navbar load hone ke baad user show karo
//       loadUser();
//     })
//     .catch(err => console.log("Navbar load error:", err));
// }

// ================= USER LOAD =================
function loadUser() {
  const user = localStorage.getItem("user");

  const emailEl = document.getElementById("userEmail");
  const avatarEl = document.getElementById("avatar");

  if (user && emailEl && avatarEl) {
    emailEl.innerText = user;
    avatarEl.src = "https://ui-avatars.com/api/?name=" + user;
  }
}

// ================= DROPDOWN =================
function toggleMenu() {
  const menu = document.getElementById("dropdown");
  if (!menu) return;

  menu.style.display =
    menu.style.display === "block" ? "none" : "block";
}

// ================= LOGOUT =================
function confirmLogout() {
  // only one confirm
  if (!confirm("Are you sure you want to logout?")) return;

  localStorage.removeItem("user");
  window.location.href = "login.html";
}

// ================= INIT =================
document.addEventListener("DOMContentLoaded", () => {
  loadNavbar(); // 🔥 sab page pe auto navbar load hoga
});



function togglePass() {
  const pass = document.getElementById("password");
  pass.type = pass.type === "password" ? "text" : "password";
}

document.addEventListener("DOMContentLoaded", () => {
  const user = localStorage.getItem("user");

  const isLoginPage = window.location.pathname.includes("login.html");
  const isSignupPage = window.location.pathname.includes("signup.html");

  // ❌ agar login nahi hai
  if (!user && !isLoginPage && !isSignupPage) {
    window.location.href = "login.html";
  }

  // ✅ agar already login hai
  if (user && (isLoginPage || isSignupPage)) {
    window.location.href = "index.html";
  }
});


// ---------- 1. Hero Section Text Animation ----------
const heroText = document.getElementById('fade');

let heroIndex = 0;

if (heroText) {
  const heroWords = [
    "Find Your Perfect PG 🏠",
    "Comfortable & Affordable 😊",
    "Live Smart, Live Happy ✨"
  ];

  setInterval(() => {
    heroText.innerText = heroWords[heroIndex];
    heroIndex = (heroIndex + 1) % heroWords.length;
  }, 3000);
}

async function askAI() {
  const input = document.getElementById("aiInput").value;
  const responseBox = document.getElementById("aiResponse");

  if (!input) return;

  responseBox.innerText = "Thinking... 🤖";

  try {
    const res = await fetch("http://localhost:5000/api/ai", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ message: input })
    });

    const data = await res.json();
    responseBox.innerText = data.reply;

  } catch (err) {
    responseBox.innerText = "Server error 😢";
  }
}


function typeText(element, text) {
  element.innerText = "";
  let i = 0;

  const interval = setInterval(() => {
    element.innerText += text[i];
    i++;
    if (i >= text.length) clearInterval(interval);
  }, 30);
}
